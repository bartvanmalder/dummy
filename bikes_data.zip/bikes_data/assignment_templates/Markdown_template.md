---
title: "Bike sharing challenge"
author: "Candidate name"
date: "January 01, 2017"
---

# Data exploration

# Modelling approach

# Performance analysis

# Conclusions

# Potential improvements
